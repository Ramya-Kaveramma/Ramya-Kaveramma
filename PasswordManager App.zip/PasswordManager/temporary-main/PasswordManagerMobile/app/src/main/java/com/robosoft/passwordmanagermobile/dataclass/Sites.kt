package com.robosoft.passwordmanagermobile.dataclass

data class Sites(val siteImage: Int, val siteName: String, val copyImg: Int, val copyPassword: String, val txtLink: String)
