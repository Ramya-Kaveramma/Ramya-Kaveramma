package com.robosoft.fragmentlifecycle

interface Communicator {
    fun passControl()
    fun passSignInControl()
}